/*
 * main.c
 *
 *  Created on: Jul 31, 2012
 *      Author: user1
 */
#include "llist.h"

int main(void){
  struct node *head='\0';
  head=addback(head, 2);
  head=addback(head, 4);
  display(head);

	/* test the llist */
  return 0;
}
