/*
 * llist.c
 *
 *  Created on: Jul 31, 2012
 *      Author: user1
 */
#include <stdio.h>
#include <stdlib.h>

struct node{
	int data;
	struct node *next;
};

/* display()
 * display all the elements of the list
 */
void display(struct node *head){
  struct node *tmp;
  tmp=head;
  if(head=='\0')
	  return;
  if(tmp->next=='\0'){
    printf("%d\n",tmp->data);
    return;
  }

  for(tmp=head; tmp->next!='\0';tmp=tmp->next){
    printf("%d\n",tmp->data);
  }
}

/*
 * addback()
 * add an element to the end of the list
 * return the new head node to the list
 */
struct node *addback(struct node *head, int data){
  struct node *tmp;
  for(tmp=head; tmp->next!='\0';tmp=tmp->next){
  }

  tmp = malloc(sizeof(tmp));

  if(tmp!='\0'){
    tmp->data=data;
    tmp->next='\0';
  }
  return tmp;
}

/**
 * find()
 * return pointer to the element in the list having the given data
 */
struct node *find(struct node *head, int data){
 struct node *tmp;
 for(tmp=head; tmp->next!='\0';tmp=tmp->next){
   if(tmp->data==data)
     return tmp;
 }
 return head;
}

/**
 * delnode()
 * deletes the element pointed to by pelement(obtained using find)
 * returns the updated head node.
 * NOTE: Make sure to conside the case when the pelement points to
 * head node
 */
struct node *delnode(struct node *head, struct node *pelement){
  struct node *tmp;
  tmp=find(head, pelement->data);
  struct node *tmp2;
  tmp2=tmp;
  tmp=tmp->next;
  free(tmp2);
  return tmp;
}

/**
 * freelist()
 * delete all the elements from the list.
 * NOTE: Make sure not to use any pointer after it is freed.
 */
void freelist(struct node *head){
  struct node *tmp;
  for(tmp=head; tmp->next!='\0';tmp=tmp->next){
    tmp=delnode(head,tmp);
  }
}


