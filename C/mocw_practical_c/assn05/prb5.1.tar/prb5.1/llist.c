/*
 * llist.c
 *
 *  Created on: Jul 31, 2012
 *      Author: user1
 */
struct node{
	int data;
	struct node *next;
};

/* display()
 * display all the elements of the list
 */
void display(struct node *head){





}

/*
 * addback()
 * add an element to the end of the list
 * return the new head node to the list
 */
struct node *addback(struct node *head, int data){





}

/**
 * find()
 * return pointer to the element in the list having the given data
 */
struct node *find(struct node *head, int data){





}

/**
 * delnode()
 * deletes the element pointed to by pelement(obtained using find)
 * returns the updated head node.
 * NOTE: Make sure to conside the case when the pelement points to
 * head node
 */
struct node *delnode(struct node *head, struct node *pelement){






}

/**
 * freelist()
 * delete all the elements from the list.
 * NOTE: Make sure not to use any pointer after it is freed.
 */
void freelist(struct node *head){




}


