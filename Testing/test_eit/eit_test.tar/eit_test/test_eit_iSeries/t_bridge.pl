#!/usr/bin/perl -w

use strict;
use LWP::UserAgent;
use IO::Socket;

my $lport = '3000';
my $eit_ip = '192.168.1.200';

my $browser = LWP::UserAgent->new;
my $response = $browser->post(
  'http://192.168.1.200/bridge',
  [
    'lp' => $lport,
    'closeSkt' => '1',
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;

open FILE, ">bridge.log";

if($response->content =~ m/value="3000"/) {
  print "Assigned port number...\n";
  print FILE "Assigned port number...\n";
}else{
  print "Cannot assign the port number..\n";
  print FILE "Cannot assign the port number..\n";
}


$response = $browser->post(
  'http://192.168.1.200/reboot',
  [
    'none' => '1',
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;
 
if($response->content =~ m/Device Rebooting/) {
  print "Device is rebooting...\n";
  print FILE "Device is rebooting...\n";
}else{
  print "Some problem...\n";
  print FILE "Some problem...\n";
} 

print "Waiting for device to reboot...\n";
print FILE "Waiting for device to reboot...\n";
sleep(15);
print "Resuming...\n";
print FILE "Resuming...\n";


my $sock = new IO::Socket::INET(
                   PeerAddr => $eit_ip,
                   PeerPort => $lport,
                   Proto    => 'tcp');
$sock or die "\nno socket :$!\n";

print "Cmd: *X01\n";
print FILE "Cmd: *X01\n";
print $sock "*X01\r\n";
my $bytes_read = sysread ($sock, my($buf), 20);
chop($buf);
print "Reply:", $buf, "\n";
print FILE "Reply:", $buf, "\n";

print "Sleeping for 2 seconds...\n";
print FILE "Sleeping for 2 seconds...\n";
sleep(2);


$lport = '2000';
$browser = LWP::UserAgent->new;
$response = $browser->post(
  'http://192.168.1.200/bridge',
  [
    'lp' => $lport,
    #'closeSkt' => '1'; 
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;


if($response->content =~ m/value="2000"/) {
  print "Assigned port number...\n";
  print FILE "Assigned port number...\n";
}else{
  print "Cannot assign the port number..\n";
  print FILE "Cannot assign the port number..\n";
}



$response = $browser->post(
  'http://192.168.1.200/reboot',
  [
    'none' => '1',
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;
 
if($response->content =~ m/Device Rebooting/) {
  print "Device is rebooting...\n";
  print FILE "Device is rebooting...\n";
}else{
  print "Some problem...\n";
  print FILE "Some problem...\n";
} 

print "Waiting for device to reboot...\n";
print FILE "Waiting for device to reboot...\n";
sleep(15);
print "Resuming...\n";
print FILE "Resuming...\n";

close FILE;
exit;
