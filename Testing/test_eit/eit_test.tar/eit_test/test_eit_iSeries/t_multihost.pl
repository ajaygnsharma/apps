#!/usr/bin/perl -w
use strict;
use LWP::UserAgent;
use IO::Socket;
use threads;
use Thread::Semaphore;

#global variables
my $semaphore = new Thread::Semaphore;
my $now_str;
my $need_to_close = 0;
my ($browser, $response);
my @thd;

#Configure these variables. 
my $test = 'simul_conn_udp'; #simul_conn, seq_conn, all(both), simul_conn_udp
my $eit_ip = '192.168.1.200';
my $mip1 : shared = '192.168.1.101';
my @mp = ('2000','2001','2002','2003','2004','2005','2006','2007','2008','2009','2010','2011');
my $conn_type = '2'; #Simultaneous
my $r_cntr = '2';
my $r_tmt_msec = '200';
my $prtcl : shared = 'tcp';
my $eit_msk = '255.255.255.0';
my $eit_gwy = '192.168.1.1';
my $eit_dns = '0.0.0.0';
my $eit_hostname = 'eitb96f';
my $eit_protocol = '1'; #1 = tcp, 2 = udp, 3 = modbus
my $http_port = '80';

open FILE, ">multihost.log"; 

########################################################################
# Post multihost page and search result 
########################################################################
sub p_network{
	$browser = LWP::UserAgent->new;
	$response = $browser->post(
	  "http://".$eit_ip."/network",
	  [
	    #'dhcp' => '1',
	    'ip' => $eit_ip,
	    'msk' => $eit_msk,
	    'gw' => $eit_gwy,
	    'dns' => $eit_dns,
	    'hname' => $eit_hostname,
	    'protocol' => $eit_protocol,
	    'port' => $http_port,
	  ],
	);
	die "Error: ", $response->status_line
	 unless $response->is_success;
	
	if($response->content =~ m/value=1 selected="selected"> TCP/) {
	  print FILE "Assigned Port as TCP, IP address: $eit_ip and http port: $http_port...\n";
	  print "Assigned Port as TCP and IP address: $eit_ip and http port: $http_port...\n";
	}else{
	  print FILE "Cannot assign tcp port and IP address...\n";
	  print "Cannot assign tcp port and IP address...\n";
	}
}

########################################################################
# Post multihost page and search result 
########################################################################
sub p_multihost{
	$browser = LWP::UserAgent->new;
	$response = $browser->post(
	  "http://".$eit_ip."/multihost",
	  [
	    'connection_type' => $conn_type,
	    'retry_counter' => $r_cntr,
	    'retry_timeout' => $r_tmt_msec,
	    'mip1' => $mip1,
	    'mp1' => $mp[0],
#	    'mip2' => $mip1,
#	    'mp2' => $mp[1],
#	    'mip3' => $mip1,
#	    'mp3' => $mp[2],
#	    'mip4' => $mip1,
#	    'mp4' => $mp[3],
#	    'mip5' => $mip1,
#	    'mp5' => $mp[4],
#	    'mip6' => $mip1,
#	    'mp6' => $mp[5],
#	    'mip7' => $mip1,
#	    'mp7' => $mp[6],
#	    'mip8' => $mip1,
#	    'mp8' => $mp[7],
#	    'mip9' => $mip1,
#	    'mp9' => $mp[8],	    
#	    'mip10' => $mip1,
#	    'mp10' => $mp[9],	    
#	    'mip11' => $mip1,
#	    'mp11' => $mp[10],	    
#	    'mip12' => $mip1,
#	    'mp12' => $mp[11],	    
	  ],
	);
	die "Error: ", $response->status_line
	 unless $response->is_success;
	
	if($response->content =~ m/$mip1/) {
	  $now_str = localtime;
	  print "Assigned remote ip:", $mip1,",",$now_str,"\n";
	  print FILE "Assigned remote ip:", $mip1,",",$now_str,"\n";
	}else{
	  print "Cannot assign remote ip....\n";
	  print FILE "Cannot assign remote ip....\n";
	}
}

########################################################################
# Defaults 
########################################################################
sub defaults{  
  $response = $browser->post(
    "http://".$eit_ip."/rdef",
    [
      'none' => '1',
    ],
  );
  die "Error: ", $response->status_line
   unless $response->is_success;
  
  print "Restored defaults\n";   
}

########################################################################
# Reboot the device 
########################################################################
sub reboot{
	$response = $browser->post(
	  "http://".$eit_ip."/reboot",
	  [
	    'none' => '1',
	  ],
	);
	die "Error: ", $response->status_line
	 unless $response->is_success;
	 
	if($response->content =~ m/Device Rebooting/) {
	  print "Device is rebooting...\n";
	  print FILE "Device is rebooting...\n";
	}else{
	  print "Some problem...\n";
	  print FILE "Some problem...\n";
	} 
	
	print "Waiting for device to reboot...\n";
	print FILE "Waiting for device to reboot...\n";
	sleep(5);
	print "Resuming...\n";
	print FILE "Resuming...\n";
}


########################################################################
# Listening TCP server 
########################################################################
sub simul_srvr{	
  	my ($port_num) = shift @_;
  	print FILE "Opening server socket\n";

  	if( $prtcl eq 'tcp'){
    	my $sock = new IO::Socket::INET(
      		LocalHost => $mip1,
      		LocalPort => $port_num,
	  		Proto     => $prtcl,
	  		Listen    =>  SOMAXCONN,
      		Reuse     => 1 );
    	$sock or die "no socket :$!\n";
    	
    	my( $new_sock, $c_addr, $buf, $i );
    	while ((($new_sock, $c_addr) = $sock->accept()) && ( $need_to_close eq 0 )) {
    		$now_str = localtime;
    		my ($client_port, $c_ip) = sockaddr_in($c_addr);
    		my $client_ipnum = inet_ntoa($c_ip);
    
    		print "got a connection from:", " [$client_ipnum]", "at ", $now_str, "\n";
    		print FILE "got a connection from:", " [$client_ipnum]", "at ", $now_str, "\n";
    		
    		for( $i = 0; $i < 10; $i++ ){
      			$semaphore->down;
      			sleep(1); #Second thread writes after 1 second. 
      			print "$i,send,*X01,";
      			print FILE "$i,send,*X01,";
      			print $new_sock "*X01\r\n";
      			my $bytes_read = sysread ($new_sock, $buf, 20);
      			$now_str = localtime;
      			chop($buf);
      			print ("recvd,$buf,$now_str \n");
      			print FILE ("recvd,$buf,$now_str \n");
      			$semaphore->up;
      			sleep(24); #sleep this thread for 24 second
    		}
    		$need_to_close = 1;    
  		}
  		close $sock;
  	}elsif($prtcl eq 'udp'){
		#Need to make a client connection first to the device and send data
		#Then the server will recieve data
		my $cl_sock = new IO::Socket::INET(
	                   PeerAddr => $eit_ip,
	                   PeerPort => $port_num,
	                   Proto    => 'udp');
	    $cl_sock or die "no socket :$!\n";
	    
	    #Create a UDP server
	  	my $sock = new IO::Socket::INET(
	      LocalHost => $mip1,
	      LocalPort => $port_num,
		  Proto     => 'udp');
	    $sock or die "no socket :$!\n";
	    
	    my( $buf, $i );
	    while ( $need_to_close eq 0 ) {
		    for( $i = 0; $i < 10; $i++ ){
		      $semaphore->down;
		      sleep(1); #Second thread writes after 1 second. 
		      
		      $now_str = localtime;
		      print("$now_str,$i,send,*X01\n");
		      $cl_sock->send("*X01\r\n");
		      
		      $semaphore->up;
		      sleep(2); #sleep this thread for 24 second
		    }
	    	$need_to_close = 1;    
	  }
  }
}

########################################################################
# Listening TCP server for sequential connections 
########################################################################
sub seq_srvr{
  my ($port_num) = shift @_;
  my $sock = new IO::Socket::INET(
    LocalHost => $mip1,
    LocalPort => $port_num,
	Proto     => $prtcl,
	Listen    =>  SOMAXCONN,
    Reuse     => 1 );
  $sock or die "no socket :$!\n";

  print FILE "Opening server socket\n";

  my( $new_sock, $c_addr, $buf, $i );
  while ((($new_sock, $c_addr) = $sock->accept()) && ( $need_to_close eq 0 )) {
    $now_str = localtime;
    my ($client_port, $c_ip) = sockaddr_in($c_addr);
    my $client_ipnum = inet_ntoa($c_ip);
    
    print "got a connection from:", " [$client_ipnum]", "at ", $now_str, "\n";
    print FILE "got a connection from:", " [$client_ipnum]", "at ", $now_str, "\n";
    for( $i = 0; $i < 10; $i++ ){
      $semaphore->down;
      sleep(1); #Second thread writes after 1 second. 
      print "$i,send,*X01,";
      print FILE "$i,send,*X01,";
      print $new_sock "*X01\r\n";
      my $bytes_read = sysread ($new_sock, $buf, 20);
      $now_str = localtime;
      chop($buf);
      print ("recvd,$buf,$now_str \n");
      print FILE ("recvd,$buf,$now_str \n");
      $semaphore->up;
      sleep(1); #sleep this thread for 24 second
    }
    $need_to_close = 1;    
  }
  close $sock;
}

########################################################################
# Main pgm Test1 Simultaneous connections 
########################################################################
if( $test eq 'simul_conn'){
	&t_simul_conn;
}elsif( $test eq 'seq_conn'){
	&t_seq_conn;	
}elsif( $test eq 'all'){
	&t_simul_conn;
	&t_seq_conn;
}elsif( $test eq 'simul_conn_udp' ){
	$eit_protocol = '2';
	$prtcl = 'udp';
	&p_network;	                                 #setup udp protocol
	&reboot;                                     #reboot device
	&t_simul_conn;
}

########################################################################
# Main pgm Test1 Simultaneous connections 
########################################################################
sub t_simul_conn{
  $conn_type = '2';                            #Simultaneous
  &p_multihost;                                #first post multihost data
  
  #Dont create 12 threads right now. Its creating a pblm use 10
  for( my $i = 0; $i < 1; $i++ ){             #create seperate thread for 
    $thd[$i] = threads->create(\&simul_srvr,$mp[$i]);#each server listening	   
  }                                            #on a different port num
 
  for( my $i = 0; $i < 1; $i++ ){
    my @ret_val;
    $ret_val[$i] = $thd[$i]->join();               #wait till threads return
    print("Thread$i returned\n");
  }

  print("Waiting for 10 seconds...");          #wait for 10 seconds before
  sleep(10);                                   #resuming since the EIT might be busy
  &defaults;                                   #restore defaults 
  &reboot;                                     #reboot device 
}


########################################################################
# Test2 Sequential connections 
########################################################################
sub t_seq_conn{
	$conn_type = '3';                            #Sequential
	&p_multihost;                                #first post multihost data
	
	for( my $i = 0; $i < 12; $i++ ){             #create seperate thread for 
	  $thd[$i] = threads->create(\&seq_srvr,$mp[$i]);#each server listening	   
	}                                            #on a different port num
	 
	for( my $i = 0; $i < 12; $i++ ){
	  my @ret_val;
	  $ret_val[$i] = $thd[$i]->join();               #wait till threads return
	  print("Thread$i returned\n");
	}
	
	print("Waiting for 10 seconds...");          #wait for 10 seconds before
	sleep(10);                                   #resuming since the EIT might be busy
	&defaults;                                   #restore defaults 
	&reboot;                                     #reboot device 
}


close FILE;
