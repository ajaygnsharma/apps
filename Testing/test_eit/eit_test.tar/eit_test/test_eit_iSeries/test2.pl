#!/usr/bin/perl -w
use strict;

require 'test1.pl';

&hello_world;
