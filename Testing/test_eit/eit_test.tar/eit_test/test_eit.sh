#!/bin/bash
echo "Running network test..."
/home/ajaysmita/Practice/perl/eit_test/t_network.pl
/home/ajaysmita/Practice/perl/eit_test/t_bridge.pl
/home/ajaysmita/Practice/perl/eit_test/t_pack.pl


