#!/usr/bin/perl
#install the module: libnet-smtp-server-perl
#Note must be root user to run this program
use strict;
use LWP::UserAgent;
use IO::Socket;
use Net::SMTP::Server;
use Net::SMTP::Server::Client;
use Data::Dumper;

my $test_post_email = 0;
my $test_e_pr = 0;
my $test_e_ipc = 0;
my $test_e_isa = 0;
my $test_e_c = 1;

if( $test_post_email eq 1 ){
my $smtp_svr_ip = '192.168.1.101';
my $smtp_from = 'eit';
my $smtp_subj = 'power_reset';
my $a1_ri = '1';
my $a1_to = 'ajay';

#First connect to the device.
my $browser = LWP::UserAgent->new;
my $response = $browser->post(
  'http://192.168.1.200/smtpsnmp',
  [
    'smtp' => '1',
    'smtpip' => $smtp_svr_ip,
    'from' => $smtp_from,
    'sub' => $smtp_subj,
    'a1_ri' => $a1_ri,
    'a1_to' => $a1_to
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;

if($response->content =~ m/"192.168.1.101"/) {
  print "Assigned SMTP server ip:", $smtp_svr_ip, "\n";
}else{
  print "Cannot assign SMTP server ip....\n";
}

}

if( $test_e_pr eq 1 ){ 
my $a1_e_pr_chk = '0';

#First connect to the device.
my $browser = LWP::UserAgent->new;
my $response = $browser->post(
  'http://192.168.1.200/alarm1',
  [
    #'a1_t_pr_chk' => '1',
    'a1_e_pr_chk' => $a1_e_pr_chk,
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;

if($response->content =~ m/"checked"/) {
  print "Enabled power reset\n";
}else{
  print "Cannot enable power reset\n";
}


$response = $browser->post(
  'http://192.168.1.200/reboot',
  [
    'none' => '1',
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;
if($response->content =~ m/Device Rebooting/) {
  print "Device is rebooting\n";
}else{
  print "Some problem\n";
} 

print "Waiting for device to reboot...\n";
sleep(15);
print "Resuming...\n";


our $host = $ARGV[0] || "0.0.0.0" ;

our $server = new Net::SMTP::Server($host) || 
  die("Unable to open SMTP server socket");

print "Waiting for incoming SMTP connections on ".($host eq "0.0.0.0" ? "all IP addresses":$host)."\n";
$| = 1;

#while(my $conn = $server->accept()) {
my $conn = $server->accept();

  print "Incoming mail ... from " . $conn->peerhost() ;
  my $client = new Net::SMTP::Server::Client($conn) || 
    die("Unable to process incoming request");
  if (!$client->process) { 
    print "\nfailed to receive complete e-mail message\n"; next; }
  print " received\n";
  print "From: $client->{FROM}\n";
  my $to = $client->{TO};
  my $toList = @{$to} ? join(",",@{$to}) : $to;
  print "To:   $toList\n";
  print "\n" ;
  print $client->{MSG};
  
if( $client->{MSG} eq "Power reset" ){
  print "Test:Power reset alarm successful...\n";
}

}



if( $test_e_ipc eq 1 ){

my $a1_e_ipc_chk = '1';

#First connect to the device.
my $browser = LWP::UserAgent->new;
my $response = $browser->post(
  'http://192.168.1.200/alarm1',
  [
    'a1_e_ipc_chk' => $a1_e_ipc_chk,
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;

if($response->content =~ m/"checked"/) {
  print "Enabled ip changed alarm\n";
}else{
  print "Cannot enable ip changed alarm\n";
}

my $browser = LWP::UserAgent->new;
my $response = $browser->post(
  'http://192.168.1.200/network',
  [
    'ip' => '192.168.1.201',
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;

if($response->content =~ m/"192.168.1.201"/) {
  print "Assigned a different ip: 192.168.1.201\n";
}else{
  print "Cannot assign a different ip\n";
}

our $host = $ARGV[0] || "0.0.0.0" ;

our $server = new Net::SMTP::Server($host) || 
  die("Unable to open SMTP server socket");

print "Waiting for incoming SMTP connections on ".($host eq "0.0.0.0" ? "all IP addresses":$host)."\n";
$| = 1;

#while(my $conn = $server->accept()) {
my $conn = $server->accept();

  print "Incoming mail ... from " . $conn->peerhost() ;
  my $client = new Net::SMTP::Server::Client($conn) || 
    die("Unable to process incoming request");
  if (!$client->process) { 
    print "\nfailed to receive complete e-mail message\n"; next; }
  print " received\n";
  print "From: $client->{FROM}\n";
  my $to = $client->{TO};
  my $toList = @{$to} ? join(",",@{$to}) : $to;
  print "To:   $toList\n";
  print "\n" ;
  print $client->{MSG};
  
if( $client->{MSG} eq "Power reset" ){
  print "Test:Power reset alarm successful...\n";
}

my $browser = LWP::UserAgent->new;
my $response = $browser->post(
  'http://192.168.1.200/network',
  [
    'ip' => '192.168.1.200',
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;

if($response->content =~ m/"192.168.1.200"/) {
  print "Reset ip to: 192.168.1.200\n";
}else{
  print "Cannot reset ip\n";
}


}


if( $test_e_isa eq 1 ){

my $a1_e_isa_chk = '1';

#First connect to the device.
my $browser = LWP::UserAgent->new;
my $response = $browser->post(
  'http://192.168.1.200/alarm1',
  [
    'a1_e_isa_chk' => $a1_e_isa_chk,
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;

if($response->content =~ m/"checked"/) {
  print "Enabled iserver accessed alarm\n";
}else{
  print "Cannot enable iserver accessed alarm\n";
}

my $lport = '2000';
my $eit_ip = '192.168.1.200';

my $sock = new IO::Socket::INET(
                   PeerAddr => $eit_ip,
                   PeerPort => $lport,
                   Proto    => 'tcp');
$sock or die "no socket :$!\n";

open FILE, ">>alarm.log";
print FILE "Enabling iserver accessed alarm\n";

my $i = 0;
for( $i = 0; $i < 1; $i++){
  print $sock "*X01\r\n";
  my $bytes_read = sysread ($sock, my($buf), 20);
  my $now_str = localtime;
  print $i,",";
  print $now_str,",";
  print $buf,"\n";

  print FILE $i,",";
  print FILE $now_str,",";
  print FILE $buf,"\n";
}

close FILE;
close $sock;



our $host = $ARGV[0] || "0.0.0.0" ;

our $server = new Net::SMTP::Server($host) || 
  die("Unable to open SMTP server socket");

print "Waiting for incoming SMTP connections on ".($host eq "0.0.0.0" ? "all IP addresses":$host)."\n";
$| = 1;

#while(my $conn = $server->accept()) {
my $conn = $server->accept();

  print "Incoming mail ... from " . $conn->peerhost() ;
  my $client = new Net::SMTP::Server::Client($conn) || 
    die("Unable to process incoming request");
  if (!$client->process) { 
    print "\nfailed to receive complete e-mail message\n"; next; }
  print " received\n";
  print "From: $client->{FROM}\n";
  my $to = $client->{TO};
  my $toList = @{$to} ? join(",",@{$to}) : $to;
  print "To:   $toList\n";
  print "\n" ;
  print $client->{MSG};
  

}





if( $test_e_c eq 1 ){

my $a1_e_c_chk = '1';

#First connect to the device.
my $browser = LWP::UserAgent->new;
my $response = $browser->post(
  'http://192.168.1.200/alarm1',
  [
    'a1_e_c_chk' => $a1_e_c_chk,
    'a1_c1' => '0x0d',
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;

if($response->content =~ m/"checked"/) {
  print "Enabled iserver character alarm\n";
}else{
  print "Cannot enable iserver character alarm\n";
}

my $lport = '2000';
my $eit_ip = '192.168.1.200';

my $sock = new IO::Socket::INET(
                   PeerAddr => $eit_ip,
                   PeerPort => $lport,
                   Proto    => 'tcp');
$sock or die "no socket :$!\n";

open FILE, ">>alarm.log";
print FILE "Enabling iserver character alarm\n";

my $i = 0;
for( $i = 0; $i < 1; $i++){
  print $sock "*X01\r\n";
  my $bytes_read = sysread ($sock, my($buf), 20);
  my $now_str = localtime;
  print $i,",";
  print $now_str,",";
  print $buf,"\n";

  print FILE $i,",";
  print FILE $now_str,",";
  print FILE $buf,"\n";
}

close FILE;
close $sock;



our $host = $ARGV[0] || "0.0.0.0" ;

our $server = new Net::SMTP::Server($host) || 
  die("Unable to open SMTP server socket");

print "Waiting for incoming SMTP connections on ".($host eq "0.0.0.0" ? "all IP addresses":$host)."\n";
$| = 1;

#while(my $conn = $server->accept()) {
my $conn = $server->accept();

  print "Incoming mail ... from " . $conn->peerhost() ;
  my $client = new Net::SMTP::Server::Client($conn) || 
    die("Unable to process incoming request");
  if (!$client->process) { 
    print "\nfailed to receive complete e-mail message\n"; next; }
  print " received\n";
  print "From: $client->{FROM}\n";
  my $to = $client->{TO};
  my $toList = @{$to} ? join(",",@{$to}) : $to;
  print "To:   $toList\n";
  print "\n" ;
  print $client->{MSG};
  

}


