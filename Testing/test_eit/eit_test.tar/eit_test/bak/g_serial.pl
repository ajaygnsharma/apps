#!/usr/bin/perl -w
# gazetteer.pl - query the US Cenus Gazetteer database

use strict;
use URI;
use LWP::UserAgent;

my $url = URI->new('http://128.100.101.145/serial.htm');
$url->query_form( 'B' => '7', 'D' => '7', P => '3', S => '1', F => '1', rs485Tmr => '0', rs485Type => '0', rs485Mode => '0');
print $url, "\n";

my $response = LWP::UserAgent->new->get( $url );
die "Error: ", $response->status_line unless $response->is_success;
extract_and_sort($response->content);

sub extract_and_sort {  # A simple data extractor routine
  die "No Parity in content" unless $_[0] =~ m{<td>Parity</td>}s;
}
