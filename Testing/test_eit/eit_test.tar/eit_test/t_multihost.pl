#!/usr/bin/perl -w

use strict;
use LWP::UserAgent;
use IO::Socket;
use Thread;

my $mip1 = '192.168.1.101';
my $mp1 = '2000';
my $mp2 = '2001';
my $end_char = '0x0d';
my $now_str;
my $need_to_close = 0;

#First connect to the device.
my $browser = LWP::UserAgent->new;
my $response = $browser->post(
  'http://192.168.1.200/multihost',
  [
    'connection_type' => '2',
    'retry_counter' => '2',
    'retry_timeout' => '200',
    'mip1' => $mip1,
    'mp1' => $mp1,
    'mip2' => $mip1,
    'mp2' => $mp2,
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;

open FILE, ">multihost.log";

if($response->content =~ m/192.168.1.101/) {
  $now_str = localtime;
  print "Assigned remote ip:", $mip1,",",$now_str,"\n";
  print FILE "Assigned remote ip:", $mip1,",",$now_str,"\n";
}else{
  print "Cannot assign remote ip....\n";
  print FILE "Cannot assign remote ip....\n";
}


sub doit1{
  my $port_num = @_;
  my $sock = new IO::Socket::INET(
                   LocalHost => '192.168.1.101',
		   #LocalPort => $port_num,
		   LocalPort => '2000',
                   Proto    => 'tcp',
		   Listen   =>  SOMAXCONN,
                   Reuse    => 1 );
  $sock or die "no socket :$!\n";

  print FILE "t1,Opening server socket\n";

  my( $new_sock, $c_addr, $buf, $i );
  while ((($new_sock, $c_addr) = $sock->accept()) && ( $need_to_close eq 0 )) {
    #eval{
      $now_str = localtime;
      my ($client_port, $c_ip) = sockaddr_in($c_addr);
      my $client_ipnum = inet_ntoa($c_ip);
    
      print "t1,got a connection from:", " [$client_ipnum]", "at ", $now_str, "\n";
      print FILE "t1,got a connection from:", " [$client_ipnum]", "at ", $now_str, "\n";
      for( $i = 0; $i < 10; $i++ ){
        print "t1,$i,send,*X01,";
        print FILE "t1,$i,send,*X01,";
        print $new_sock "*X01\r\n";
        my $bytes_read = sysread ($new_sock, $buf, 20);
        $now_str = localtime;
        chop($buf);
        print ("recvd,$buf,$now_str \n");
        print FILE ("recvd,$buf,$now_str \n");
        sleep(2);
      }
      $need_to_close = 1;
     # alarm 40;
     # local $SIG{ALRM} = sub { die "alarm time out\n" };
    #}or die "recv from timeout after 40 seconds\n";
  }
  close $sock;
}


sub doit2{
  my $port_num = @_;
  my $sock = new IO::Socket::INET(
                   LocalHost => '192.168.1.101',
		   #LocalPort => $port_num,
		   LocalPort => '2001',
                   Proto    => 'tcp',
		   Listen   =>  SOMAXCONN,
                   Reuse    => 1 );
  $sock or die "no socket :$!\n";

  print FILE "Opening server socket\n";

  my( $new_sock, $c_addr, $buf, $i );
  while ((($new_sock, $c_addr) = $sock->accept()) && ( $need_to_close eq 0 )) {
    #eval{
      $now_str = localtime;
      my ($client_port, $c_ip) = sockaddr_in($c_addr);
      my $client_ipnum = inet_ntoa($c_ip);
    
      print "t2,got a connection from:", " [$client_ipnum]", "at ", $now_str, "\n";
      print FILE "t2,got a connection from:", " [$client_ipnum]", "at ", $now_str, "\n";
      for( $i = 0; $i < 10; $i++ ){
        print "t2,$i,send,*X01,";
        print FILE "t2,$i,send,*X01,";
        print $new_sock "*X01\r\n";
        my $bytes_read = sysread ($new_sock, $buf, 20);
        $now_str = localtime;
        chop($buf);
        print ("recvd,$buf,$now_str \n");
        print FILE ("recvd,$buf,$now_str \n");
        sleep(2);
      }
      $need_to_close = 1;
     # alarm 40;
     # local $SIG{ALRM} = sub { die "alarm time out\n" };
    #}or die "recv from timeout after 40 seconds\n";
  }
  close $sock;
}


#for( @hosts ){
  #my $t1 = new Thread \&doit, $_;
  my $t1 = threads->create( \&doit1,'2000');
  my $t2 = threads->create( \&doit2,'2001'); 
  my @ReturnData1 = $t1->join();
  print("Thread1 returned\n");
  my @ReturnData2 = $t2->join();
  print("Thread2 returned\n");
#}

$browser = LWP::UserAgent->new;
$response = $browser->post(
  'http://192.168.1.200/multihost',
  [
    'connection_type' => '1',
    'retry_counter' => '2',
    'retry_timeout' => '200',
    'mip1' => '0.0.0.0',
    'mp1' => '0',
    'mip2' => '0.0.0.0', 
    'mp2' => '0',
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;


if($response->content =~ m/0.0.0.0/) {
  $now_str = localtime;
  print "Resetting remote ip: 0.0.0.0,$now_str,\n";
  print FILE "Resetting remote ip: 0.0.0.0,$now_str,\n";
}else{
  print "Cannot reset remote ip....\n";
  print FILE "Cannot reset remote ip....\n";
}

$response = $browser->post(
  'http://192.168.1.200/reboot',
  [
    'none' => '1',
  ],
);
die "Error: ", $response->status_line
 unless $response->is_success;
 
if($response->content =~ m/Device Rebooting/) {
  print "Device is rebooting...\n";
  print FILE "Device is rebooting...\n";
}else{
  print "Some problem...\n";
  print FILE "Some problem...\n";
} 

print "Waiting for device to reboot...\n";
print FILE "Waiting for device to reboot...\n";
sleep(15);
print "Resuming...\n";
print FILE "Resuming...\n";

close FILE;

