#!/usr/bin/perl -w

use strict;
use LWP::UserAgent;
use IO::Socket;

my $lport = '3000';
my $eit_ip = '128.100.101.204';

#my $browser = LWP::UserAgent->new;
#my $response = $browser->post(
#  'http://128.100.101.204/bridge',
#  [
#    'N' => '2',
#    'lp' => $lport,
#  ],
#);
#die "Error: ", $response->status_line
# unless $response->is_success;

#if($response->content =~ m/value="3000"/) {
#  print "Assigned port number\n";
#}else{
#  print "Cannot assign the port number.\n";
#}



#$response = $browser->post(
#  'http://128.100.101.204/reboot',
#  [
#    'none' => '1',
#  ],
#);
#die "Error: ", $response->status_line
# unless $response->is_success;
 
#if($response->content =~ m/Device Rebooting/) {
#  print "Device is rebooting\n";
#}else{
#  print "Some problem\n";
#} 

#print "Waiting for device to rebooti\n";

#sleep( 15 );

#print "Resuming...\n";

# IO::Socket
use IO::Socket;

#my $host = shift || inet_aton($eit_ip);
#my $port = shift || 3000;

my $sock = new IO::Socket::INET(
                   PeerAddr => $eit_ip,
                   PeerPort => $lport,
                   Proto    => 'tcp');
$sock or die "\nno socket :$!\n";

#print "socket 1..\n";

#print $sock "*01Z02\r\n";
#print $sock "*01X01\r\n";

#my $bytes_read = sysread ($sock, my($buf), 20);

#my $buf = <$sock>;

#print "\n";
#print $buf;
#print "\n";

#close $sock;

my $sock1 = new IO::Socket::INET(
                   PeerAddr => $eit_ip,
                   PeerPort => $lport,
                   Proto    => 'tcp');
$sock1 or die "\nCannot make second connection :$!\n";

my $sock2 = new IO::Socket::INET(
                   PeerAddr => $eit_ip,
                   PeerPort => $lport,
                   Proto    => 'tcp');
$sock2 or die "\nCannot make third connection :$!\n";

my $sock3 = new IO::Socket::INET(
                   PeerAddr => $eit_ip,
                   PeerPort => $lport,
                   Proto    => 'tcp');
$sock3 or die "no socket :$!";

my $sock4 = new IO::Socket::INET(
                   PeerAddr => $eit_ip,
                   PeerPort => $lport,
                   Proto    => 'tcp');
$sock4 or die "no socket :$!";

my $sock5 = new IO::Socket::INET(
                   PeerAddr => $eit_ip,
                   PeerPort => $lport,
                   Proto    => 'tcp');
$sock5 or die "no socket :$!";




print "sending data";


exit;
