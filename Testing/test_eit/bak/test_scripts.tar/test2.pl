#!/usr/bin/perl -w
# IO::Socket
use strict;
use IO::Socket;
my $host = shift || inet_aton('128.100.101.145');
my $port = shift || 3000;
my $sock = new IO::Socket::INET(
                   PeerAddr => '128.100.101.145',
                   PeerPort => 3000,
                   Proto    => 'tcp');
$sock or die "no socket :$!";

print "sending data";

#foreach my $i (1..10) {
    #print $sock "*01Z02\r\n";
    print $sock "*01X01\r\n";
#}

my $bytes_read = sysread ($sock, my($buf), 20);

#my $buf = <$sock>;

print "\r\n";

print $buf;

print "\r\n";

close $sock;
