#include <stdio.h>
#include <stdlib.h>

int main(int argc, char * argv[])
{
  int i;
  printf("Hello world\n"); 
  for(i=0;i<10;i++){
    printf("%d\n",i);
  }
  return 0;
}
